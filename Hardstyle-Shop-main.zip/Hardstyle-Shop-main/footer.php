<?php
?>
<link rel="stylesheet" type="text/css" href="styles.css">
<footer>
    <div class="foot-row">
        <img src="image/logo.jpg" style="width:250px">
        <div class="foot">
            <div class="foot-box">
                <a href="#">Facebook</a>
                <a href="#">TikTok</a>
                </div>
            <div class="foot-box">
                <a href="https://www.instagram.com/stephanie.magic_/">Instagram</a>
                <a href="https://www.youtube.com/watch?v=_0uzelh0DOw&ab_channel=IAMHARDSTYLE">Youtube</a>
            </div>
        </div>
        <div class="foot">
            <p>Openingstijden</p>
            <p>ma tot vr 10:00 tot 17:00</p>
            <p>za 9:00 tot 20:00</p>
        </div>
    </div>
</footer>
</html>
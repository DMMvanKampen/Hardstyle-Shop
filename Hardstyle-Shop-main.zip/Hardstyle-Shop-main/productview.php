<?php

include "header.php";

?>
<html>
<head>
    <title>Webshop</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
<!--product_id, product_name, description, quantity, price-->
<?php

include 'product.php';

?>
</body>
<?php

include "footer.php";

?>
</html>